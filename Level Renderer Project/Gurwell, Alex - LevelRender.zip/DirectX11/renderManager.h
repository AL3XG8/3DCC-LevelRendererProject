#include <d3dcompiler.h>
#pragma comment(lib, "d3dcompiler.lib") //needed for runtime shader compilation. Consider compiling shaders before runtime 

#include "load_object_oriented.h"
#include <commdlg.h>

struct SceneData
{
	GW::MATH::GVECTORF sunDirection, sunColor, sunAmbient, cameraPos;
	GW::MATH::GMATRIXF viewProjectionMatrix;
};

GW::SYSTEM::UNIVERSAL_WINDOW_HANDLE uwh = {};

class RenderManager
{
	// proxy handles
	GW::SYSTEM::GWindow win;
	GW::GRAPHICS::GDirectX11Surface d3d;
	GW::SYSTEM::GLog info;
	Level_Objects gameLevel;

	Microsoft::WRL::ComPtr<ID3D11VertexShader>	vertexShader;
	Microsoft::WRL::ComPtr<ID3D11PixelShader>	pixelShader;

	GW::MATH::GMATRIXF world;
	GW::MATH::GMATRIXF view;
	GW::MATH::GMATRIXF projection;
	GW::MATH::GMATRIXF viewProjection;
	GW::MATH::GMatrix matrixProxy;

	MeshData mData;
	SceneData sData;

	Microsoft::WRL::ComPtr<ID3D11Buffer> meshConstantBuffer;
	Microsoft::WRL::ComPtr<ID3D11Buffer> sceneConstantBuffer;

	GW::INPUT::GInput gInput;
	GW::AUDIO::GAudio gAudio;
	GW::AUDIO::GMusic gMusic;

public:

	RenderManager(GW::SYSTEM::GWindow _win, GW::GRAPHICS::GDirectX11Surface _d3d)
	{
		win = _win;
		d3d = _d3d;

		info.Create("output.txt");
		info.EnableConsoleLogging(true);

		bool levelLoaded = gameLevel.LoadLevel("../Levels/Level 2/Level2.txt", "../Levels/Level 2/Models", info);

		InitializeWorldMatrix();
		InitializeViewProjectionMatrix();
		InitializeLight();

		gInput.Create(win);
		gAudio.Create();

		if (gMusic.Create("../Audio/DSLofi.wav", gAudio) == GW::GReturn::SUCCESS)
		{
			gMusic.SetVolume(0.05f);
			gMusic.Play(true);
		}
		else
		{
			std::cout << "Failed to create or play music." << std::endl;
		}

		IntializeGraphics();

		gameLevel.UploadLevelToGPU(d3d);
	}

private:

	void InitializeWorldMatrix()
	{
		matrixProxy.Create();
		matrixProxy.IdentityF(world);

		mData.worldMatrix = world;
	}

	void InitializeViewProjectionMatrix()
	{
		matrixProxy.IdentityF(view);
		GW::MATH::GVECTORF cameraPosition = { 0.0f, 15.0f, -40.0f, 1.0f };
		GW::MATH::GVECTORF targetPosition = { 0.0f, -15.0f, 0.0f, 1.0f };
		GW::MATH::GVECTORF upDirection = { 0.0f, 1.0f, 0.0f, 0.0f };
		matrixProxy.LookAtLHF(cameraPosition, targetPosition, upDirection, view);

		sData.cameraPos = cameraPosition;

		float fovY = 65.0f * (G_PI_F / 180.0f);
		float aspectRatio;
		float nearPlane = 0.1f;
		float farPlane = 200.0f;
		d3d.GetAspectRatio(aspectRatio);

		matrixProxy.IdentityF(projection);
		matrixProxy.ProjectionDirectXLHF(fovY, aspectRatio, nearPlane, farPlane, projection);
		matrixProxy.MultiplyMatrixF(view, projection, viewProjection);

		sData.viewProjectionMatrix = viewProjection;
	}

	void InitializeLight()
	{
		GW::MATH::GVECTORF lightDirection = { -1.0f, -1.0f, 2.0f, 0.0f };
		sData.sunDirection = NormalizeVector(lightDirection);
		sData.sunColor = { 0.9f, 0.9f, 1.0f, 1.0f };
		sData.sunAmbient = { 1.0f, 1.0f, 1.0f, 1.0f };
	}

	GW::MATH::GVECTORF NormalizeVector(GW::MATH::GVECTORF& vector)
	{
		float length = sqrt(vector.x * vector.x + vector.y * vector.y + vector.z * vector.z);

		if (length != 0)
		{
			vector.x /= length;
			vector.y /= length;
			vector.z /= length;
		}

		return vector;
	}

	void IntializeGraphics()
	{
		ID3D11Device* creator;

		d3d.GetDevice((void**)&creator);

		InitializeMeshSceneBuffers(creator);

		// free temporary handle
		creator->Release();
	}

	void InitializeMeshSceneBuffers(ID3D11Device* creator)
	{
		CreateMeshBuffer(creator, &mData, sizeof(MeshData));
		CreateSceneBuffer(creator, &sData, sizeof(SceneData));
	}

	void CreateMeshBuffer(ID3D11Device* creator, const void* data, unsigned int sizeInBytes)
	{
		D3D11_SUBRESOURCE_DATA iData = { data, 0, 0 };
		CD3D11_BUFFER_DESC bDesc(sizeInBytes, D3D11_BIND_CONSTANT_BUFFER, D3D11_USAGE_DYNAMIC, D3D11_CPU_ACCESS_WRITE);
		creator->CreateBuffer(&bDesc, &iData, meshConstantBuffer.GetAddressOf());
	}

	void CreateSceneBuffer(ID3D11Device* creator, const void* data, unsigned int sizeInBytes)
	{
		D3D11_SUBRESOURCE_DATA iData = { data, 0, 0 };
		CD3D11_BUFFER_DESC bDesc(sizeInBytes, D3D11_BIND_CONSTANT_BUFFER, D3D11_USAGE_DYNAMIC, D3D11_CPU_ACCESS_WRITE);
		creator->CreateBuffer(&bDesc, &iData, sceneConstantBuffer.GetAddressOf());
	}

public:

	void Render()
	{
		PipelineHandles curHandles = GetCurrentPipelineHandles();

		SetUpPipeline(curHandles);

		D3D11_MAPPED_SUBRESOURCE mappedResource;

		gameLevel.RenderLevel(curHandles, mData, meshConstantBuffer, mappedResource);

		curHandles.context->Map(sceneConstantBuffer.Get(), 0, D3D11_MAP_WRITE_DISCARD, 0, &mappedResource);
		memcpy(mappedResource.pData, &sData, sizeof(SceneData));
		curHandles.context->Unmap(sceneConstantBuffer.Get(), 0);

		ReleasePipelineHandles(curHandles);
	}

	void ChangeLevel()
	{
		float f1State = 0.0f;
		gInput.GetState(G_KEY_F1, f1State);

		if (f1State == 1.0f)
		{
			win.GetWindowHandle(uwh);
			OPENFILENAME ofn;
			wchar_t szFile[260] = { 0 };
			ZeroMemory(&ofn, sizeof(ofn));
			ofn.lStructSize = sizeof(ofn);
			ofn.hwndOwner = reinterpret_cast<HWND>(uwh.window);
			ofn.lpstrFile = szFile;
			ofn.nMaxFile = sizeof(szFile);
			ofn.lpstrFilter = L"Text Files\0*.txt\0All Files\0*.*\0";
			ofn.nFilterIndex = 1;
			ofn.lpstrFileTitle = NULL;
			ofn.nMaxFileTitle = 0;
			ofn.lpstrInitialDir = L"C:/Users/adg8t/OneDrive/Documents/Full Sail/3DCC/GitHub/3dcc-course-materials-AL3XG8/Level Renderer Project/DirectX11/Levels";
			ofn.Flags = OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST;

			if (GetOpenFileName(&ofn) == TRUE)
			{
				std::wstring ws(ofn.lpstrFile);
				std::wstring_convert<std::codecvt_utf8<wchar_t>> converter;
				std::string fullLevelPath = converter.to_bytes(ws);

				size_t lastSlashPos = fullLevelPath.find_last_of("\\/");
				std::string levelFilename;

				if (lastSlashPos != std::string::npos)
				{
					levelFilename = fullLevelPath.substr(lastSlashPos + 1);
				}
				else
				{
					levelFilename = fullLevelPath;
				}

				const char* levelPath = levelFilename.c_str();
				const char* modelPath = "Models";

				bool levelLoaded = gameLevel.LoadLevel(levelPath, "Models", info);
			}
		}
	}

	void UpdateCamera()
	{
		static std::chrono::steady_clock::time_point lastTime = std::chrono::steady_clock::now();
		std::chrono::steady_clock::time_point currentTime = std::chrono::steady_clock::now();
		std::chrono::duration<float> deltaTime = std::chrono::duration_cast<std::chrono::duration<float>>(currentTime - lastTime);
		lastTime = currentTime;

		const float cameraSpeed = 10.0f; // Camera Speed
		const float mouseSensitivity = 0.001f; // Mouse Sensitivity
		float totalYChange = 0.0f; // Vertical
		float totalZChange = 0.0f; // Forward - Backward
		float totalXChange = 0.0f; // Left - Right
		float totalPitch = 0.0f; // Pitch
		float totalYaw = 0.0f; // Yaw

		// Vertical
		float spaceKeyState = 0.0f, leftShiftKeyState = 0.0f;
		gInput.GetState(G_KEY_SPACE, spaceKeyState);
		gInput.GetState(G_KEY_LEFTSHIFT, leftShiftKeyState);
		totalYChange += spaceKeyState;
		totalYChange -= leftShiftKeyState;

		// Forward - Backward
		float wKeyState = 0.0f, sKeyState = 0.0f;
		gInput.GetState(G_KEY_W, wKeyState);
		gInput.GetState(G_KEY_S, sKeyState);
		totalZChange += wKeyState;
		totalZChange -= sKeyState;

		// Left - Right
		float aKeyState = 0.0f, dKeyState = 0.0f;
		gInput.GetState(G_KEY_A, aKeyState);
		gInput.GetState(G_KEY_D, dKeyState);
		totalXChange += dKeyState;
		totalXChange -= aKeyState;

		// Mouse Sens Rotation
		float mouseXDelta = 0.0f;
		float mouseYDelta = 0.0f;
		GW::GReturn isMovingMouse = gInput.GetMouseDelta(mouseXDelta, mouseYDelta);
		if (isMovingMouse == GW::GReturn::REDUNDANT)
		{
			mouseXDelta = 0.0f;
			mouseYDelta = 0.0f;
		}
		/*else
		{
			std::cout << "Mouse X Delta: " << mouseXDelta << std::endl;
			std::cout << "Mouse Y Delta: " << mouseYDelta << std::endl;
		}*/
		totalPitch += mouseYDelta * mouseSensitivity;
		totalYaw += mouseXDelta * mouseSensitivity;

		float perFrameSpeed = cameraSpeed * deltaTime.count();

		GW::MATH::GMATRIXF cameraWorldMatrix;
		matrixProxy.InverseF(view, cameraWorldMatrix);

		GW::MATH::GVECTORF localMovementVector = { totalXChange * perFrameSpeed, 0.0f, totalZChange * perFrameSpeed, 0.0f };
		matrixProxy.TranslateLocalF(cameraWorldMatrix, localMovementVector, cameraWorldMatrix);

		GW::MATH::GVECTORF globalMovementVector = { 0.0f, totalYChange * perFrameSpeed, 0.0f, 0.0f };
		matrixProxy.TranslateGlobalF(cameraWorldMatrix, globalMovementVector, cameraWorldMatrix);

		matrixProxy.RotateXLocalF(cameraWorldMatrix, totalPitch, cameraWorldMatrix);
		matrixProxy.RotateYGlobalF(cameraWorldMatrix, totalYaw, cameraWorldMatrix);

		matrixProxy.InverseF(cameraWorldMatrix, view);

		matrixProxy.MultiplyMatrixF(view, projection, viewProjection);

		sData.viewProjectionMatrix = viewProjection;
	}

private:

	PipelineHandles GetCurrentPipelineHandles()
	{
		PipelineHandles retval;
		d3d.GetImmediateContext((void**)&retval.context);
		d3d.GetRenderTargetView((void**)&retval.targetView);
		d3d.GetDepthStencilView((void**)&retval.depthStencil);
		return retval;
		GCOLLISION_H
	}

	void SetUpPipeline(PipelineHandles handles)
	{
		SetRenderTargets(handles);
		//SetVertexIndexBuffers(handles);
		//SetShaders(handles);

		handles.context->VSSetConstantBuffers(0, 1, meshConstantBuffer.GetAddressOf());
		handles.context->PSSetConstantBuffers(0, 1, meshConstantBuffer.GetAddressOf());

		handles.context->PSSetConstantBuffers(1, 1, sceneConstantBuffer.GetAddressOf());
		handles.context->VSSetConstantBuffers(1, 1, sceneConstantBuffer.GetAddressOf());

		//handles.context->IASetInputLayout(vertexFormat.Get());
		handles.context->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLELIST);
	}

	void SetRenderTargets(PipelineHandles handles)
	{
		ID3D11RenderTargetView* const views[] = { handles.targetView };
		handles.context->OMSetRenderTargets(ARRAYSIZE(views), views, handles.depthStencil);
	}

	void ReleasePipelineHandles(PipelineHandles toRelease)
	{
		toRelease.depthStencil->Release();
		toRelease.targetView->Release();
		toRelease.context->Release();
	}

public:
	~RenderManager()
	{
		// ComPtr will auto release so nothing to do here yet
	}
};
